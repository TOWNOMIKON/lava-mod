# lava-mod-for-mindustry
не судите строго (do not judge strictly)
